
public abstract class Bank {
	
	public abstract float RateOfInterest();

}