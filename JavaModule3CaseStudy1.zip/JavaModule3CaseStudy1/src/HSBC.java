
public class HSBC {

	String name = "HSBC";
	float rateOfInterest = 3.5f;
	
	public String getName () {
		
		return name;
		
	}

	public float RateOfInterest() {

		return rateOfInterest;


	}

}

