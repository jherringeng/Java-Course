
public class RBS extends Bank{

	String name = "RBS";
	float rateOfInterest = 4.1f;

	public String getName () {

		return name;

	}

	public float RateOfInterest() {

		return rateOfInterest;

	}

}
