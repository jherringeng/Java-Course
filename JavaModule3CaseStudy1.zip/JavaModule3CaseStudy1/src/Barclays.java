
public class Barclays {

	String name = "Barclays";
	float rateOfInterest = 3.3f;
	
	public String getName () {
		
		return name;
		
	}

	public float RateOfInterest() {

		return rateOfInterest;


	}

}