
public class Santander {

	String name = "Santander";
	float rateOfInterest = 3.9f;
	
	public String getName () {
		
		return name;
		
	}

	public float RateOfInterest() {

		return rateOfInterest;


	}

}
