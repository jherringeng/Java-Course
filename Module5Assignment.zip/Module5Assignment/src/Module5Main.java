
public class Module5Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WrapperClass wrapperClass = new WrapperClass();

		wrapperClass.wrapperConversions();
		
		Collection collection = new Collection();
			
		collection.insert1to10();
		collection.createEmployeeRecords();
		collection.createStudentRecords();
		
	}

}
