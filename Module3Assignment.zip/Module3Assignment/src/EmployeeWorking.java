
public class EmployeeWorking {
	
	
	double earnings;
	
	public double earn() {
	
		return earnings;
		
	}

	
	public void work() {
		
	}
	
}
